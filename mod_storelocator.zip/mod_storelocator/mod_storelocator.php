<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;

$db = Factory::getContainer()->get('DatabaseDriver');

// Modul-Parameter auslesen (oder Standardwerte nutzen)
$tableName = $params->get('table_name', 'sl_locations');
$defaultRadius = (int)$params->get('default_radius', 25);

// Alle aktiven Händler laden
$query = $db->getQuery(true)
    ->select(['id', 'name', 'address', 'postal', 'town', 'country', 'latitude', 'longitude', 'phone', 'email', 'website'])
    ->from($db->quoteName($tableName))
    ->where($db->quoteName('published') . ' = 1');

$db->setQuery($query);
$allLocations = $db->loadObjectList() ?: [];
?>

<!-- Leaflet CSS & JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<div style="max-width: 1200px; margin: 0 auto; padding: 0 15px; box-sizing: border-box; font-family: system-ui, -apple-system, sans-serif;">
    
    <!-- Aktions-Bar mit Ortssuche & GPS -->
    <div style="background: #ffffff; border: 1px solid #e5e5e5; border-radius: 6px; padding: 15px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
        <div style="display: flex; flex-wrap: wrap; gap: 15px; align-items: flex-end; justify-content: space-between;">
            
            <!-- Ortssuche -->
            <div style="flex: 1 1 250px; display: flex; gap: 8px;">
                <div style="flex: 1;">
                    <label for="sl_search_input" style="display: block; font-weight: 600; font-size: 0.85rem; margin-bottom: 5px; color: #444;">PLZ / Ort suchen</label>
                    <input type="text" id="sl_search_input" placeholder="z. B. Berlin, Salzburg, 58706" onkeypress="if(event.key === 'Enter'){ searchByCity(); event.preventDefault(); }" style="width: 100%; padding: 8px 12px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 0.9rem;">
                </div>
                <button type="button" onclick="searchByCity()" style="margin-top: auto; padding: 8px 16px; background: #0066cc; color: #fff; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; white-space: nowrap;">
                    🔍 Suchen
                </button>
            </div>

            <!-- Umkreis & Standort-Button -->
            <div style="display: flex; align-items: flex-end; gap: 12px; flex-wrap: wrap;">
                <div>
                    <label for="sl_radius" style="display: block; font-weight: 600; font-size: 0.85rem; margin-bottom: 5px; color: #444;">Umkreis</label>
                    <select id="sl_radius" onchange="filterLocationsByRadius()" style="padding: 8px 12px; border: 1px solid #ccc; border-radius: 4px; background: #fff; font-size: 0.9rem;">
                        <option value="10" <?php echo ($defaultRadius === 10) ? 'selected' : ''; ?>>10 km</option>
                        <option value="25" <?php echo ($defaultRadius === 25) ? 'selected' : ''; ?>>25 km</option>
                        <option value="50" <?php echo ($defaultRadius === 50) ? 'selected' : ''; ?>>50 km</option>
                        <option value="100" <?php echo ($defaultRadius === 100) ? 'selected' : ''; ?>>100 km</option>
                    </select>
                </div>

                <button type="button" id="sl-geo-btn" onclick="locateUser()" style="padding: 9px 18px; background: #222; color: #fff; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; white-space: nowrap;">
                    📍 Mein Standort
                </button>
            </div>

        </div>

        <!-- Statusanzeige mit Zurücksetzen-Link -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 12px; padding-top: 10px; border-top: 1px solid #f0f0f0;">
            <span id="sl-status-msg" style="font-size: 0.85rem; color: #666;">
                ⚪ Geben Sie einen Ort ein oder nutzen Sie Ihren Standort, um Händler anzuzeigen.
            </span>
            <button type="button" onclick="resetSearch()" style="background: none; border: none; color: #888; font-size: 0.8rem; cursor: pointer; text-decoration: underline; padding: 0;">
                Suche zurücksetzen
            </button>
        </div>
    </div>

    <!-- Layout Grid -->
    <div style="display: grid; grid-template-columns: 1fr; gap: 20px; align-items: start;" class="sl-map-grid">
        <style>
            @media (min-width: 768px) { 
                .sl-map-grid { 
                    grid-template-columns: 360px 1fr !important; 
                } 
            }
            .my-location-marker {
                background-color: #d9534f;
                border: 3px solid #ffffff;
                border-radius: 50%;
                box-shadow: 0 0 10px rgba(0,0,0,0.5);
            }
            @media (min-width: 768px) {
                #sl-map-container {
                    position: sticky !important;
                    top: 20px !important;
                }
            }
        </style>

        <!-- Liste Links -->
        <div style="background: #fff; border: 1px solid #e5e5e5; border-radius: 6px; padding: 15px; box-sizing: border-box;">
            <h4 style="margin-top: 0; font-size: 1.1rem; border-bottom: 2px solid #0066cc; padding-bottom: 8px; color: #222; margin-bottom: 10px;">
                Händler in der Nähe (<span id="sl-count">0</span>)
            </h4>
            
            <div id="sl-dealer-list">
                <div style="text-align: center; padding: 40px 10px; color: #777;">
                    <div style="font-size: 2rem; margin-bottom: 10px;">📍</div>
                    <p style="font-size: 0.9rem; margin: 0; line-height: 1.5;">
                        Geben Sie eine Stadt ein oder klicken Sie auf <strong>„Mein Standort“</strong>, um Händler im Umkreis zu finden.
                    </p>
                </div>
            </div>
        </div>

        <!-- Karte Rechts -->
        <div id="sl-map-container">
            <div id="sl-map" style="width: 100%; height: 520px; border-radius: 6px; border: 1px solid #e5e5e5; z-index: 1;"></div>
        </div>
    </div>
</div>

<script>
var rawLocations = <?php echo json_encode($allLocations); ?>;

var countryNames = {
    'DE': 'Deutschland', 'AT': 'Österreich', 'CH': 'Schweiz', 'FR': 'Frankreich',
    'NL': 'Niederlande', 'BE': 'Belgien', 'LU': 'Luxemburg', 'IT': 'Italien',
    'PL': 'Polen', 'CZ': 'Tschechien', 'ES': 'Spanien', 'GB': 'Großbritannien'
};

function getCountryName(code) {
    if (!code) return '';
    var upperCode = String(code).trim().toUpperCase();
    return countryNames[upperCode] || upperCode;
}

var map = L.map('sl-map').setView([51.165, 10.451], 6);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap'
}).addTo(map);

var currentUserLat = null;
var currentUserLng = null;
var currentSearchLabel = '';
var userMarker = null;
var dealerMarkers = [];

function calculateDistance(lat1, lon1, lat2, lon2) {
    var R = 6371;
    var dLat = (lat2 - lat1) * Math.PI / 180;
    var dLon = (lon2 - lon1) * Math.PI / 180;
    var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
}

function searchByCity() {
    var inputVal = document.getElementById('sl_search_input').value.trim();
    if (!inputVal) return;

    var msg = document.getElementById('sl-status-msg');
    msg.innerText = '⏳ Ort "' + inputVal + '" wird gesucht...';

    var url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(inputVal);

    fetch(url)
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data && data.length > 0) {
                currentUserLat = parseFloat(data[0].lat);
                currentUserLng = parseFloat(data[0].lon);
                currentSearchLabel = data[0].display_name.split(',')[0];

                setCenterMarker(currentSearchLabel);
                filterLocationsByRadius();
            } else {
                msg.innerText = '⚠️ Der Ort "' + inputVal + '" konnte nicht gefunden werden.';
            }
        })
        .catch(function(err) {
            msg.innerText = '⚠️ Fehler bei der Ortssuche. Bitte erneut versuchen.';
        });
}

function locateUser() {
    if (navigator.geolocation) {
        var btn = document.getElementById('sl-geo-btn');
        var msg = document.getElementById('sl-status-msg');

        btn.innerText = '⏳ Ortung...';
        msg.innerText = 'Standort wird abgerufen...';

        navigator.geolocation.getCurrentPosition(
            function(position) {
                currentUserLat = position.coords.latitude;
                currentUserLng = position.coords.longitude;
                currentSearchLabel = 'Mein Standort';

                btn.innerText = '📍 Mein Standort';
                setCenterMarker(currentSearchLabel);
                filterLocationsByRadius();
            },
            function(err) {
                btn.innerText = '📍 Mein Standort';
                msg.innerText = 'Standortabfrage nicht freigegeben oder abgelehnt.';
            },
            { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }
        );
    } else {
        alert("Ihr Browser unterstützt keine Geolocation.");
    }
}

function setCenterMarker(label) {
    if (userMarker) { map.removeLayer(userMarker); }

    var myIcon = L.divIcon({
        className: 'my-location-marker',
        iconSize: [20, 20],
        iconAnchor: [10, 10]
    });

    userMarker = L.marker([currentUserLat, currentUserLng], { icon: myIcon })
        .addTo(map)
        .bindPopup("<b>" + escapeHtml(label) + "</b>");
}

function filterLocationsByRadius() {
    if (currentUserLat === null || currentUserLng === null) return;

    var selectedRadius = parseInt(document.getElementById('sl_radius').value, 10);
    clearDealerMarkers();

    var listContainer = document.getElementById('sl-dealer-list');
    listContainer.innerHTML = '';

    var matchedLocations = [];

    rawLocations.forEach(function(loc) {
        if (loc.latitude && loc.longitude) {
            var dist = calculateDistance(currentUserLat, currentUserLng, parseFloat(loc.latitude), parseFloat(loc.longitude));
            if (dist <= selectedRadius) {
                loc.distanz = dist;
                matchedLocations.push(loc);
            }
        }
    });

    matchedLocations.sort(function(a, b) { return a.distanz - b.distanz; });

    document.getElementById('sl-count').innerText = matchedLocations.length;
    document.getElementById('sl-status-msg').innerText = '🟢 Zentrum: ' + currentSearchLabel + ' (' + selectedRadius + ' km Radius)';

    var bounds = [[currentUserLat, currentUserLng]];

    if (matchedLocations.length > 0) {
        matchedLocations.forEach(function(loc) {
            addDealerToListAndMap(loc, loc.distanz);
            bounds.push([parseFloat(loc.latitude), parseFloat(loc.longitude)]);
        });
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 13 });
    } else {
        listContainer.innerHTML = '<p style="font-size: 0.9rem; color: #777; padding: 10px 0;">Keine Händler im Umkreis von ' + selectedRadius + ' km gefunden.</p>';
        map.setView([currentUserLat, currentUserLng], 11);
    }
}

function addDealerToListAndMap(loc, distanz) {
    var lat = parseFloat(loc.latitude);
    var lng = parseFloat(loc.longitude);

    var countryText = getCountryName(loc.country);
    var addressText = (loc.postal ? escapeHtml(loc.postal) + ' ' : '') + 
                      (loc.town ? escapeHtml(loc.town) : '') + 
                      (countryText ? ' (' + escapeHtml(countryText) + ')' : '');

    var cleanAddressParts = [loc.address, loc.postal, loc.town, countryText].filter(Boolean);
    var fullAddressForUrl = encodeURIComponent(cleanAddressParts.join(', '));
    var mapsUrl = 'https://www.google.com/maps/dir/?api=1&destination=' + fullAddressForUrl;

    var popupContent = "<b>" + escapeHtml(loc.name) + "</b><br>" +
                       escapeHtml(loc.address) + "<br>" +
                       addressText +
                       (loc.phone ? '<br>📞 ' + escapeHtml(loc.phone) : '') +
                       (loc.website ? '<br><a href="' + escapeHtml(loc.website) + '" target="_blank" style="color:#0066cc;font-weight:600;">Website besuchen &rarr;</a>' : '') +
                       '<br><a href="' + mapsUrl + '" target="_blank" rel="noopener" style="display:inline-block; margin-top:6px; color:#1a73e8; font-weight:600; text-decoration:none;">🚗 Route auf Google Maps &rarr;</a>';

    var marker = L.marker([lat, lng]).addTo(map).bindPopup(popupContent);
    dealerMarkers.push(marker);

    var item = document.createElement('div');
    item.style.cssText = 'padding: 12px 0; border-bottom: 1px solid #eee; cursor: pointer;';
    item.onclick = function() {
        map.setView([lat, lng], 14);
        marker.openPopup();
    };

    var html = '<strong style="color: #222; font-size: 0.95rem; display: block;">' + escapeHtml(loc.name) + '</strong>' +
               '<div style="font-size: 0.85rem; color: #555; margin-top: 3px; line-height: 1.4;">' +
               escapeHtml(loc.address) + '<br>' + addressText + '</div>';

    if (loc.phone) {
        html += '<div style="font-size: 0.8rem; color: #777; margin-top: 3px;">📞 ' + escapeHtml(loc.phone) + '</div>';
    }
    
    if (loc.website) {
        html += '<div style="margin-top: 4px;"><a href="' + escapeHtml(loc.website) + '" target="_blank" style="color: #0066cc; font-size: 0.8rem; font-weight: 600; text-decoration: none;">🌐 Website besuchen</a></div>';
    }

    if (distanz !== null) {
        html += '<a href="' + mapsUrl + '" target="_blank" rel="noopener" onclick="event.stopPropagation();" style="display: inline-block; margin-top: 8px; background: #eef5ff; color: #1a73e8; font-size: 0.78rem; font-weight: 700; padding: 4px 8px; border-radius: 4px; border: 1px solid #cce0ff; text-decoration: none;">' +
                '🚗 ' + distanz.toFixed(1).replace('.', ',') + ' km &bull; Route starten &rarr;' +
                '</a>';
    }

    item.innerHTML = html;
    document.getElementById('sl-dealer-list').appendChild(item);
}

function clearDealerMarkers() {
    dealerMarkers.forEach(function(m) { map.removeLayer(m); });
    dealerMarkers = [];
}

function resetSearch() {
    currentUserLat = null;
    currentUserLng = null;
    currentSearchLabel = '';
    
    if (userMarker) { map.removeLayer(userMarker); }
    clearDealerMarkers();

    document.getElementById('sl_search_input').value = '';
    document.getElementById('sl-count').innerText = '0';
    document.getElementById('sl-status-msg').innerText = '⚪ Geben Sie einen Ort ein oder nutzen Sie Ihren Standort, um Händler anzuzeigen.';
    
    document.getElementById('sl-dealer-list').innerHTML = 
        '<div style="text-align: center; padding: 40px 10px; color: #777;">' +
        '<div style="font-size: 2rem; margin-bottom: 10px;">📍</div>' +
        '<p style="font-size: 0.9rem; margin: 0; line-height: 1.5;">Geben Sie eine Stadt ein oder klicken Sie auf <strong>„Mein Standort“</strong>, um Händler im Umkreis zu finden.</p>' +
        '</div>';

    map.setView([51.165, 10.451], 6);
}

function escapeHtml(text) {
    if (!text) return '';
    return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
</script>